import{b as l}from"./_baseIndexOf.BTknn6Gb.js";function r(n,e){var t=n==null?0:n.length;return!!t&&l(n,e,0)>-1}export{r as a};
